Andrew Pokorney - Assn 3 , CIS - 395

